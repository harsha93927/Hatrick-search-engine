import { ExternalLink, Sparkles } from 'lucide-react';

interface SearchResultCardProps {
  title: string;
  description: string;
  url?: string;
  source?: string;
  isAIAnswer?: boolean;
  imageUrl?: string;
}

export default function SearchResultCard({ title, description, url, source, isAIAnswer, imageUrl }: SearchResultCardProps) {
  return (
    <div className="group relative bg-gradient-to-br from-gray-900 to-black rounded-xl overflow-hidden border-2 border-gray-800 hover:border-yellow-500 transition-all duration-300 transform hover:scale-105 hover:shadow-xl hover:shadow-yellow-500/20">
      <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/0 via-yellow-500/5 to-yellow-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

      {imageUrl && (
        <div className="h-48 overflow-hidden bg-gray-800">
          <img
            src={imageUrl}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = 'none';
            }}
          />
        </div>
      )}

      <div className="p-6 relative">
        <div className="flex items-center justify-between mb-3 gap-2">
          <div className="flex items-center gap-2">
            {isAIAnswer && <Sparkles className="text-yellow-500" size={18} />}
            <span className="text-yellow-500 text-xs font-semibold">{source || 'Source'}</span>
          </div>
        </div>

        <h3 className="text-lg font-bold text-white mb-2 line-clamp-2 group-hover:text-yellow-400 transition-colors">
          {title}
        </h3>

        <p className="text-gray-300 text-sm mb-4 leading-relaxed line-clamp-3">
          {description}
        </p>

        {url && (
          <a
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-yellow-500 hover:text-yellow-400 transition-colors font-semibold text-sm"
          >
            Visit Source <ExternalLink size={14} />
          </a>
        )}
      </div>
    </div>
  );
}
