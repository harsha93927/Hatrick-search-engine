import { useState, useEffect } from 'react';
import { Search, Loader2 } from 'lucide-react';
import NewsCard from './NewsCard';
import SearchResultCard from './SearchResultCard';

interface NewsArticle {
  title: string;
  description: string;
  url: string;
  source: { name: string };
  publishedAt: string;
  urlToImage?: string;
}

interface SearchResult {
  title: string;
  description: string;
  url?: string;
  source?: string;
  isAIAnswer?: boolean;
  imageUrl?: string;
  isNews?: boolean;
}

export default function SearchInterface() {
  const [searchQuery, setSearchQuery] = useState('');
  const [news, setNews] = useState<NewsArticle[]>([]);
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isLoadingNews, setIsLoadingNews] = useState(true);

  useEffect(() => {
    fetchNews();
  }, []);

  const fetchNews = async () => {
    setIsLoadingNews(true);
    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/news-api`,
        {
          headers: {
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          },
        }
      );
      const data = await response.json();
      if (data.articles) {
        setNews(data.articles.slice(0, 6));
      }
    } catch (error) {
      console.error('Error fetching news:', error);
    } finally {
      setIsLoadingNews(false);
    }
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    setSearchResults([]);

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/search-api`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ query: searchQuery }),
        }
      );
      const data = await response.json();
      setSearchResults(data.results || []);
    } catch (error) {
      console.error('Error searching:', error);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="min-h-screen bg-black">
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/10 via-black to-black"></div>
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-yellow-500 to-transparent animate-pulse"></div>

        <div className="relative max-w-7xl mx-auto px-4 py-8">
          <div className="text-center mb-12">
            <h1 className="text-5xl md:text-6xl font-bold mb-4">
              <span className="bg-gradient-to-r from-yellow-400 via-yellow-500 to-yellow-600 text-transparent bg-clip-text animate-gradient">
                Hatrick
              </span>
              <span className="text-white"> Search</span>
            </h1>
            <p className="text-gray-400">Your gateway to information</p>
          </div>

          <form onSubmit={handleSearch} className="mb-12">
            <div className="max-w-3xl mx-auto relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-full opacity-75 group-hover:opacity-100 blur transition duration-300"></div>
              <div className="relative flex items-center">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search anything..."
                  className="w-full px-8 py-4 bg-gray-900 text-white rounded-full border-2 border-yellow-500 focus:outline-none focus:border-yellow-400 transition-all placeholder-gray-500"
                />
                <button
                  type="submit"
                  disabled={isSearching}
                  className="absolute right-2 bg-yellow-500 hover:bg-yellow-400 text-black p-3 rounded-full transition-all transform hover:scale-110 disabled:opacity-50"
                >
                  {isSearching ? (
                    <Loader2 className="animate-spin" size={20} />
                  ) : (
                    <Search size={20} />
                  )}
                </button>
              </div>
            </div>
          </form>

          {searchResults.length > 0 && (
            <div className="mb-16">
              <h2 className="text-3xl font-bold text-white mb-6">
                <span className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-transparent bg-clip-text">Search Results</span>
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {searchResults.map((result, index) => (
                  <SearchResultCard key={index} {...result} />
                ))}
              </div>
            </div>
          )}

          <div>
            <h2 className="text-3xl font-bold text-white mb-6">Latest News</h2>
            {isLoadingNews ? (
              <div className="flex justify-center items-center py-20">
                <Loader2 className="animate-spin text-yellow-500" size={40} />
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {news.map((article, index) => (
                  <NewsCard
                    key={index}
                    title={article.title}
                    description={article.description || ''}
                    url={article.url}
                    source={article.source.name}
                    publishedAt={article.publishedAt}
                    imageUrl={article.urlToImage}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
