import { useState } from 'react';
import IntroScreen from './components/IntroScreen';
import SearchInterface from './components/SearchInterface';

function App() {
  const [showIntro, setShowIntro] = useState(true);

  return (
    <>
      {showIntro && <IntroScreen onComplete={() => setShowIntro(false)} />}
      {!showIntro && <SearchInterface />}
    </>
  );
}

export default App;
