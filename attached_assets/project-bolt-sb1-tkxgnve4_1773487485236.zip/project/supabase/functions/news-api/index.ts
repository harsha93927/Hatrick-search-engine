const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const NEWS_API_KEY = Deno.env.get('NEWS_API_KEY');

    if (!NEWS_API_KEY) {
      const mockNews = {
        articles: [
          {
            title: "Breaking: AI Technology Advances",
            description: "New developments in artificial intelligence are reshaping the tech industry with breakthrough innovations.",
            url: "https://example.com/ai-news",
            source: { name: "Tech News" },
            publishedAt: new Date().toISOString(),
            urlToImage: "https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg"
          },
          {
            title: "Global Markets Show Strong Growth",
            description: "Stock markets worldwide are experiencing unprecedented growth as investor confidence reaches new heights.",
            url: "https://example.com/market-news",
            source: { name: "Financial Times" },
            publishedAt: new Date().toISOString(),
            urlToImage: "https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg"
          },
          {
            title: "Climate Action: Nations Unite",
            description: "World leaders announce ambitious new climate goals in historic international agreement.",
            url: "https://example.com/climate-news",
            source: { name: "World News" },
            publishedAt: new Date().toISOString(),
            urlToImage: "https://images.pexels.com/photos/1268975/pexels-photo-1268975.jpeg"
          },
          {
            title: "Space Exploration Milestone Reached",
            description: "NASA announces successful completion of groundbreaking space mission.",
            url: "https://example.com/space-news",
            source: { name: "Science Daily" },
            publishedAt: new Date().toISOString(),
            urlToImage: "https://images.pexels.com/photos/2166711/pexels-photo-2166711.jpeg"
          },
          {
            title: "Innovation in Renewable Energy",
            description: "New solar technology promises to revolutionize clean energy production worldwide.",
            url: "https://example.com/energy-news",
            source: { name: "Green Tech" },
            publishedAt: new Date().toISOString(),
            urlToImage: "https://images.pexels.com/photos/433308/pexels-photo-433308.jpeg"
          },
          {
            title: "Medical Breakthrough Announced",
            description: "Researchers discover promising new treatment for major health conditions.",
            url: "https://example.com/medical-news",
            source: { name: "Health Today" },
            publishedAt: new Date().toISOString(),
            urlToImage: "https://images.pexels.com/photos/356040/pexels-photo-356040.jpeg"
          }
        ]
      };

      return new Response(JSON.stringify(mockNews), {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      });
    }

    const response = await fetch(
      `https://newsapi.org/v2/top-headlines?country=us&pageSize=6&apiKey=${NEWS_API_KEY}`
    );

    const data = await response.json();

    return new Response(JSON.stringify(data), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json',
      },
    });
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});
