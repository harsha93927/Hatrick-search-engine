const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

async function fetchNewsResults(query: string, newsApiKey: string) {
  try {
    const response = await fetch(
      `https://newsapi.org/v2/everything?q=${encodeURIComponent(query)}&sortBy=relevancy&pageSize=8&apiKey=${newsApiKey}`
    );
    const data = await response.json();

    if (data.articles) {
      return data.articles.map((article: any) => ({
        title: article.title,
        description: article.description || article.content,
        url: article.url,
        imageUrl: article.urlToImage,
        source: article.source.name,
        isNews: true,
      }));
    }
  } catch (error) {
    console.error('News API error:', error);
  }
  return [];
}

async function fetchPixelsImage(query: string) {
  try {
    const response = await fetch(
      `https://api.pexels.com/v1/search?query=${encodeURIComponent(query)}&per_page=1`,
      {
        headers: {
          'Authorization': Deno.env.get('PEXELS_API_KEY') || 'demo',
        }
      }
    );
    const data = await response.json();
    if (data.photos && data.photos.length > 0) {
      return data.photos[0].src.medium;
    }
  } catch (error) {
    console.error('Pexels API error:', error);
  }
  return null;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { query } = await req.json();

    if (!query) {
      return new Response(
        JSON.stringify({ error: "Query is required" }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');
    const GOOGLE_SEARCH_API_KEY = Deno.env.get('GOOGLE_SEARCH_API_KEY');
    const GOOGLE_CX_ID = Deno.env.get('GOOGLE_CX_ID');
    const NEWS_API_KEY = Deno.env.get('NEWS_API_KEY');

    const results = [];
    const imagePromise = fetchPixelsImage(query);

    if (OPENAI_API_KEY) {
      try {
        const aiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${OPENAI_API_KEY}`,
          },
          body: JSON.stringify({
            model: 'gpt-3.5-turbo',
            messages: [
              {
                role: 'system',
                content: 'You are a helpful assistant providing concise and accurate answers.'
              },
              {
                role: 'user',
                content: query
              }
            ],
            max_tokens: 300,
          }),
        });

        const aiData = await aiResponse.json();

        if (aiData.choices && aiData.choices[0]) {
          const imageUrl = await imagePromise;
          results.push({
            title: 'AI-Powered Answer',
            description: aiData.choices[0].message.content,
            isAIAnswer: true,
            source: 'ChatGPT',
            imageUrl: imageUrl,
          });
        }
      } catch (error) {
        console.error('OpenAI API error:', error);
      }
    }

    if (GOOGLE_SEARCH_API_KEY && GOOGLE_CX_ID) {
      try {
        const searchUrl = `https://www.googleapis.com/customsearch/v1?key=${GOOGLE_SEARCH_API_KEY}&cx=${GOOGLE_CX_ID}&q=${encodeURIComponent(query)}&num=10`;
        const searchResponse = await fetch(searchUrl);
        const searchData = await searchResponse.json();

        if (searchData.items) {
          for (const item of searchData.items.slice(0, 8)) {
            let imageUrl = null;
            if (item.pagemap && item.pagemap.cse_image) {
              imageUrl = item.pagemap.cse_image[0]?.src;
            }

            if (!imageUrl) {
              imageUrl = await fetchPixelsImage(query);
            }

            results.push({
              title: item.title,
              description: item.snippet,
              url: item.link,
              source: 'Google Search',
              imageUrl: imageUrl,
            });
          }
        }
      } catch (error) {
        console.error('Google Search API error:', error);
      }
    }

    if (NEWS_API_KEY) {
      try {
        const newsResults = await fetchNewsResults(query, NEWS_API_KEY);
        results.push(...newsResults.slice(0, 6));
      } catch (error) {
        console.error('News API fetch error:', error);
      }
    }

    if (results.length === 0) {
      const imageUrl = await imagePromise;
      results.push(
        {
          title: 'AI-Powered Answer',
          description: `Comprehensive information about "${query}": This search engine integrates with multiple sources including ChatGPT, Google Search, and News APIs. Configure your API keys to get detailed answers and real-time information from across the web.`,
          isAIAnswer: true,
          source: 'Hatrick Search',
          imageUrl: imageUrl,
        },
        {
          title: 'Web Search Results',
          description: `To enhance your search for "${query}", we've prepared this search engine to pull results from top news outlets, Google Search, and AI sources. Enable API keys for comprehensive results.`,
          source: 'Search Info',
          imageUrl: imageUrl,
        },
        {
          title: 'Multiple Source Integration',
          description: 'Add your API keys (OPENAI_API_KEY, GOOGLE_SEARCH_API_KEY, GOOGLE_CX_ID, NEWS_API_KEY) to enable: AI-powered insights, web search results, and breaking news from major publications.',
          source: 'Setup Guide',
          imageUrl: imageUrl,
        },
        {
          title: 'Real-Time Data',
          description: `Searching for "${query}" - Once configured, this engine will fetch the latest information from multiple sources simultaneously, giving you comprehensive coverage.`,
          source: 'Feature Info',
          imageUrl: imageUrl,
        }
      );
    }

    return new Response(
      JSON.stringify({ results }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});
